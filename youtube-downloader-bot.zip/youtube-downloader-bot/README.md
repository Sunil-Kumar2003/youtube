# YouTube Video Downloader Bot

A simple Python CLI tool to download YouTube videos using `pytube`.

## How to Run

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the script:
```bash
python downloader.py
```

3. Enter a YouTube URL when prompted.
