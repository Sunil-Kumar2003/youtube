import pytube

def download_video(url):
    try:
        yt = pytube.YouTube(url)
        stream = yt.streams.get_highest_resolution()
        print(f"Downloading: {yt.title}")
        stream.download()
        print("Download complete!")
    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    video_url = input("Enter YouTube video URL: ")
    download_video(video_url)
